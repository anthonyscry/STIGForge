##########################################################################
# Evaluate-STIG module
# --------------------
# STIG:     Active Directory Forest
# Version:  V3R2
# Class:    UNCLASSIFIED
# Updated:  12/11/2025
# Author:   Naval Sea Systems Command (NAVSEA)
##########################################################################
$ErrorActionPreference = "Stop"

Function Get-V243502 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243502
        STIG ID    : AD.0017
        Rule ID    : SV-243502r1026198_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Membership to the Schema Admins group must be limited.
        DiscussMD5 : 608E2CC587FC8AC66CEFBF3A89BE61DE
        CheckMD5   : 9E69F74F8FBC7E15DE82F4630B5A8076
        FixMD5     : 7A7CB30C127DCE872B3386F1EE3A30CA
    #>

    param (
        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $false)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Instance,

        [Parameter(Mandatory = $false)]
        [String]$Database,

        [Parameter(Mandatory = $false)]
        [String]$SiteName
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $FuncDescription = ($MyInvocation.MyCommand.ScriptBlock -split "#>")[0].split("`r`n")
    $VulnID = ($FuncDescription | Select-String -Pattern "V-\d{4,6}$").Matches[0].Value
    $RuleID = ($FuncDescription | Select-String -Pattern "SV-\d{4,6}r\d{1,}_rule$").Matches[0].Value
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $Group = "Schema Admins"
    $Members = Get-MembersOfADGroup $Group
    If (($Members | Measure-Object).Count -le 0) {
        $Status = "NotAFinding"
        $FindingDetails += "'$Group' - Contains no members"
    }
    Else {
        If (($Members | Measure-Object).Count -eq 1 -and $Members.Name -eq "BUILTIN\Administrators") {
            $Status = "NotAFinding"
        }
        $FindingStatus += "Members of '$($Group)':"
        $FindingDetails += "=========================" | Out-String
        ForEach ($Member in $Members) {
            $FindingDetails += "Name:`t`t`t`t$($Member.name)" | Out-String
            $FindingDetails += "objectClass:`t`t`t$($Member.objectClass)" | Out-String
            $FindingDetails += "objectSID:`t`t`t$($Member.objectSID.Value)" | Out-String
            $FindingDetails += "DistinguishedName:`t$($Member.distinguishedName)" | Out-String
            $FindingDetails += "" | Out-String
        }
    }
    #---=== End Custom Code ===---#

    if ($FindingDetails.Trim().Length -gt 0) {
        $ResultHash = Get-TextHash -Text $FindingDetails -Algorithm SHA1
    }
    else {
        $ResultHash = ""
    }

    if ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            RuleID       = $RuleID
            AnswerKey    = $PSBoundParameters.AnswerKey
            Status       = $Status
            Hostname     = $Hostname
            Username     = $Username
            UserSID      = $UserSID
            Instance     = $Instance
            Database     = $Database
            Site         = $Site
            ResultHash   = $ResultHash
            ResultData   = $FindingDetails
            ShowRun      = $ShowRunningConfig
            ESPath       = $ESPath
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }

        $AnswerData = (Get-CorporateComment @GetCorpParams)
        if ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    $SendCheckParams = @{
        Module           = $ModuleName
        Status           = $Status
        FindingDetails   = $FindingDetails
        AFKey            = $AFkey
        AFStatus         = $AFStatus
        Comments         = $Comments
        SeverityOverride = $SeverityOverride
        Justification    = $Justification
        HeadInstance     = $Instance
        HeadDatabase     = $Database
        HeadSite         = $Site
        HeadHash         = $ResultHash
    }
    if ($AF_UserHeader) {
        $SendCheckParams.Add("HeadUsername", $Username)
        $SendCheckParams.Add("HeadUserSID", $UserSID)
    }

    return Send-CheckResult @SendCheckParams
}

Function Get-V243503 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243503
        STIG ID    : AD.0230
        Rule ID    : SV-243503r1026201_rule
        CCI ID     : CCI-000366
        Rule Name  : SRG-OS-000480
        Rule Title : Anonymous Access to AD forest data above the rootDSE level must be disabled.
        DiscussMD5 : 763378AC6C7FF7A2E608E0D6A2185865
        CheckMD5   : 93F0EA734ECFD25A255A83ACC8765D1C
        FixMD5     : ECAFEF7396CD1FA3E4F89F0E67078393
    #>

    param (
        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $false)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Instance,

        [Parameter(Mandatory = $false)]
        [String]$Database,

        [Parameter(Mandatory = $false)]
        [String]$SiteName
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $FuncDescription = ($MyInvocation.MyCommand.ScriptBlock -split "#>")[0].split("`r`n")
    $VulnID = ($FuncDescription | Select-String -Pattern "V-\d{4,6}$").Matches[0].Value
    $RuleID = ($FuncDescription | Select-String -Pattern "SV-\d{4,6}r\d{1,}_rule$").Matches[0].Value
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $SettingName = "Anonymous access to AD Forest"  # GPO setting name identified in STIG
    $SettingState = "Disabled"  # GPO configured state identified in STIG.

    Try {
        ForEach ($dc in ((Get-CimInstance Win32_ComputerSystem).Domain).ToString().Split(".")) {
            $Domain += ",dc=$($dc)"
        }
        $LdapObject = ("CN=Directory Service,CN=Windows NT,CN=Services,CN=Configuration" + $Domain)
        $ReturnedValue = (Get-ADObject -Identity $LdapObject -Properties dsHeuristics).dsHeuristics

        If ($ReturnedValue.Length -eq 0) {
            $Status = "NotAFinding"
            $FindingDetails += "'dsHeuristics' is not configured." | Out-String
        }
        Else {
            If ($ReturnedValue.Length -ge 7 -and $ReturnedValue[6] -eq "2") {
                $Status = "Open"
                $FindingDetails += "'$($SettingName)' is NOT $($SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "dsHeuristics:`t'$ReturnedValue'" | Out-String
            }
            Else {
                $Status = "NotAFinding"
                $FindingDetails += "'$($SettingName)' is $($SettingState)" | Out-String
                $FindingDetails += "" | Out-String
                $FindingDetails += "dsHeuristics:`t'$ReturnedValue'" | Out-String
            }
        }
    }
    Catch {
        $FindingDetails += "Unable to determine if $($SettingName) is set to $($SettingState). Manual review required." | Out-String
    }
    #---=== End Custom Code ===---#

    if ($FindingDetails.Trim().Length -gt 0) {
        $ResultHash = Get-TextHash -Text $FindingDetails -Algorithm SHA1
    }
    else {
        $ResultHash = ""
    }

    if ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            RuleID       = $RuleID
            AnswerKey    = $PSBoundParameters.AnswerKey
            Status       = $Status
            Hostname     = $Hostname
            Username     = $Username
            UserSID      = $UserSID
            Instance     = $Instance
            Database     = $Database
            Site         = $Site
            ResultHash   = $ResultHash
            ResultData   = $FindingDetails
            ShowRun      = $ShowRunningConfig
            ESPath       = $ESPath
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }

        $AnswerData = (Get-CorporateComment @GetCorpParams)
        if ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    $SendCheckParams = @{
        Module           = $ModuleName
        Status           = $Status
        FindingDetails   = $FindingDetails
        AFKey            = $AFkey
        AFStatus         = $AFStatus
        Comments         = $Comments
        SeverityOverride = $SeverityOverride
        Justification    = $Justification
        HeadInstance     = $Instance
        HeadDatabase     = $Database
        HeadSite         = $Site
        HeadHash         = $ResultHash
    }
    if ($AF_UserHeader) {
        $SendCheckParams.Add("HeadUsername", $Username)
        $SendCheckParams.Add("HeadUserSID", $UserSID)
    }

    return Send-CheckResult @SendCheckParams
}

Function Get-V243504 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243504
        STIG ID    : AD.0295
        Rule ID    : SV-243504r1026204_rule
        CCI ID     : CCI-001891, CCI-004923
        Rule Name  : SRG-OS-000355
        Rule Title : The Windows Time Service on the forest root PDC Emulator must be configured to acquire its time from an external time source.
        DiscussMD5 : A801BF7F75D7556FBBABC591127DEA33
        CheckMD5   : 37A6B25709C6C3B8A07F84C6C5F4F9FC
        FixMD5     : 2392D416D1ACC3A627F987FF68F6B001
    #>

    param (
        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $false)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Instance,

        [Parameter(Mandatory = $false)]
        [String]$Database,

        [Parameter(Mandatory = $false)]
        [String]$SiteName
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $FuncDescription = ($MyInvocation.MyCommand.ScriptBlock -split "#>")[0].split("`r`n")
    $VulnID = ($FuncDescription | Select-String -Pattern "V-\d{4,6}$").Matches[0].Value
    $RuleID = ($FuncDescription | Select-String -Pattern "SV-\d{4,6}r\d{1,}_rule$").Matches[0].Value
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    # Get PDCEmulator FSMO role holder
    $PDCEmulator = (Get-ADForest | Select-Object -ExpandProperty RootDomain | Get-ADDomain | Select-Object -ExpandProperty PDCEmulator).ToLower()
    # Get the fully qualified domain name of the computer currently be evaluated
    $ComputerSystem = Get-CimInstance Win32_ComputerSystem
    $FQDN = ("$($computerSystem.DNSHostName).$($computerSystem.Domain)").ToLower()


    If ($PDCEmulator -ne $FQDN) {
        $Status = "Not_Applicable"
        $FindingDetails += "This system is not the PDC Emulator for the forest root so this requirement is NA."
    }
    ElseIf ((Get-Service W32Time).Status -notmatch "^Running$") {
        $FindingDetails += "W32Time service is not running.  Unable to complete this check."
    }
    Else {
        $Compliant = $true
        $DomainRole = Get-DomainRoleStatus
        $W32TM = Get-W32TMConfiguration

        $FindingDetails += "DomainRole:`t$($DomainRole.RoleFriendlyName)" | Out-String
        $FindingDetails += "" | Out-String
        ForEach ($Key in ($W32TM.TimeProviders.Keys -match '^NtpClient')) {
            $FindingDetails += "$Key" | Out-String
            If ($W32TM.TimeProviders[$Key].Type -match '^NTP') {
                $FindingDetails += "Type:`t`t" + ($W32TM.TimeProviders[$Key].Type) | Out-String
                If ($W32TM.TimeProviders[$Key].NtpServer) {
                    $FindingDetails += "NtpServer:`t" + $W32TM.TimeProviders[$Key].NtpServer | Out-String
                }
                Else {
                    $Compliant = $false
                    $FindingDetails += "NtpServer:`tNot Configured [expected time server address]" | Out-String
                }
            }
            Else {
                $Compliant = $false
                $FindingDetails += "Type:`t`t" + ($W32TM.TimeProviders[$Key].Type) + " [expected 'NTP']" | Out-String
            }
            $FindingDetails += "" | Out-String
        }

        If ($Compliant -eq $false) {
            $Status = "Open"
        }
    }
    #---=== End Custom Code ===---#

    if ($FindingDetails.Trim().Length -gt 0) {
        $ResultHash = Get-TextHash -Text $FindingDetails -Algorithm SHA1
    }
    else {
        $ResultHash = ""
    }

    if ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            RuleID       = $RuleID
            AnswerKey    = $PSBoundParameters.AnswerKey
            Status       = $Status
            Hostname     = $Hostname
            Username     = $Username
            UserSID      = $UserSID
            Instance     = $Instance
            Database     = $Database
            Site         = $Site
            ResultHash   = $ResultHash
            ResultData   = $FindingDetails
            ShowRun      = $ShowRunningConfig
            ESPath       = $ESPath
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }

        $AnswerData = (Get-CorporateComment @GetCorpParams)
        if ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    $SendCheckParams = @{
        Module           = $ModuleName
        Status           = $Status
        FindingDetails   = $FindingDetails
        AFKey            = $AFkey
        AFStatus         = $AFStatus
        Comments         = $Comments
        SeverityOverride = $SeverityOverride
        Justification    = $Justification
        HeadInstance     = $Instance
        HeadDatabase     = $Database
        HeadSite         = $Site
        HeadHash         = $ResultHash
    }
    if ($AF_UserHeader) {
        $SendCheckParams.Add("HeadUsername", $Username)
        $SendCheckParams.Add("HeadUserSID", $UserSID)
    }

    return Send-CheckResult @SendCheckParams
}

Function Get-V243506 {
    <#
    .DESCRIPTION
        Vuln ID    : V-243506
        STIG ID    : DS00.3140_AD
        Rule ID    : SV-243506r1026208_rule
        CCI ID     : CCI-002235
        Rule Name  : SRG-OS-000324
        Rule Title : Update access to the directory schema must be restricted to appropriate accounts.
        DiscussMD5 : C596EE0EF7B7A86E7B75342D8CA7BDA5
        CheckMD5   : E5011257F11C74A03A17171319BFCCA5
        FixMD5     : 97EF59000E79EEF8F612FE8117143690
    #>

    param (
        [Parameter(Mandatory = $true)]
        [String]$ScanType,

        [Parameter(Mandatory = $false)]
        [String]$AnswerFile,

        [Parameter(Mandatory = $false)]
        [String]$AnswerKey,

        [Parameter(Mandatory = $false)]
        [String]$Instance,

        [Parameter(Mandatory = $false)]
        [String]$Database,

        [Parameter(Mandatory = $false)]
        [String]$SiteName
    )

    $ModuleName = (Get-Command $MyInvocation.MyCommand).Source
    $FuncDescription = ($MyInvocation.MyCommand.ScriptBlock -split "#>")[0].split("`r`n")
    $VulnID = ($FuncDescription | Select-String -Pattern "V-\d{4,6}$").Matches[0].Value
    $RuleID = ($FuncDescription | Select-String -Pattern "SV-\d{4,6}r\d{1,}_rule$").Matches[0].Value
    $Status = "Not_Reviewed"  # Acceptable values are 'Not_Reviewed', 'Open', 'NotAFinding', 'Not_Applicable'
    $FindingDetails = ""
    $Comments = ""
    $AFStatus = ""
    $SeverityOverride = ""  # Acceptable values are 'CAT_I', 'CAT_II', 'CAT_III'.  Only use if STIG calls for a severity change based on specified critera.
    $Justification = ""  # If SeverityOverride is used, a justification is required.
    # $ResultObject = [System.Collections.Generic.List[System.Object]]::new()

    #---=== Begin Custom Code ===---#
    $NonNormCount = 0
    $NonNormPerms = @()

    If (($PsVersionTable.PSVersion -join ".") -lt [Version]"6.0") {
        $SchemaPermissions = $(Get-Acl "AD:$((Get-ADRootDSE).schemaNamingContext)").Access | Sort-Object IdentityReference, ActiveDirectoryRights | Select-Object IdentityReference, ActiveDirectoryRights, ObjectType
    }
    Else {
        $PSCommand = 'PowerShell.exe -NoProfile -Command {$(Get-Acl "AD:$((Get-ADRootDSE).schemaNamingContext)").Access | Sort-Object IdentityReference, ActiveDirectoryRights | Select-Object IdentityReference, ActiveDirectoryRights, ObjectType}'
        $SchemaPermissions = Invoke-Expression $PSCommand
    }

    $FindingDetails += "`nSchema Permissions:" | Out-String
    ForEach ($SchemaPermission in $SchemaPermissions) {
        If (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\Authenticated Users") -and ($SchemaPermission.ActiveDirectoryRights -eq "GenericRead")) {
            $FindingDetails += "  Permissions are set to the default for: Authenticated Users - Read" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\SYSTEM") -and ($SchemaPermission.ActiveDirectoryRights -eq "GenericAll")) {
            $FindingDetails += "  Permissions are set to the default for: System - Full Control" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -like "*\Enterprise Read-only Domain Controllers") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Read-only Domain Controllers - Replicating Directory Changes" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -like "*\Enterprise Read-only Domain Controllers") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Read-only Domain Controllers - Replicating Directory Changes All" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -like "*\Enterprise Read-only Domain Controllers") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "89e95b76-444d-4c62-991a-0facbeda640c")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Read-only Domain Controllers - Replicating Directory Changes In Filtered Set" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -Like "*\Schema Admins") -and (($SchemaPermission.ActiveDirectoryRights -like "*CreateChild*") -or ($SchemaPermission.ActiveDirectoryRights -like "*Self*") -or ($SchemaPermission.ActiveDirectoryRights -like "*WriteProperty*") -or ($SchemaPermission.ActiveDirectoryRights -like "*GenericRead*") -or ($SchemaPermission.ActiveDirectoryRights -like "*WriteDacl*") -or ($SchemaPermission.ActiveDirectoryRights -like "*WriteOwner*"))) {
            $FindingDetails += "  Permissions are set to the default for: Schema Admins - Special (except Full, Delete, and Delete subtree)" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -like "*\Schema Admins") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "e12b56b6-0a95-11d1-adbb-00c04fd8d5cd")) {
            $FindingDetails += "  Permissions are set to the default for: Schema Admins - Change schema master" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ac-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Manage replication topology" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Replicating Directory Changes" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Replicating Directory Changes All" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "89e95b76-444d-4c62-991a-0facbeda640c")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Replicating Directory Changes In Filtered Set" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "BUILTIN\Administrators") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ab-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Administrators - Replication Synchronization" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ac-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Manage replication topology" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6aa-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Replicating Directory Changes" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ad-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Replicating Directory Changes All" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "89e95b76-444d-4c62-991a-0facbeda640c")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Replicating Directory Changes In Filtered Set" | Out-String
        }
        ElseIf (($SchemaPermission.IdentityReference -eq "NT AUTHORITY\ENTERPRISE DOMAIN CONTROLLERS") -and ($SchemaPermission.ActiveDirectoryRights -eq "ExtendedRight") -and ($SchemaPermission.ObjectType -eq "1131f6ab-9c07-11d1-f79f-00c04fc2dcd2")) {
            $FindingDetails += "  Permissions are set to the default for: Enterprise Domain Controllers - Replication Synchronization" | Out-String
        }
        Else {
            ++$NonNormCount
            $NonNormPerms += $SchemaPermission | Select-Object IdentityReference, ActiveDirectoryRights, ObjectType
        }
    }

    If ($NonNormCount -ge 1) {
        $Status = "Open"
        $FindingDetails += "`nNon Standard Permissions in the Schema Permissions:" | Out-String
        $FindingDetails += "_______________________________________________________________________" | Out-String
        ForEach ($Object in $NonNormPerms) {
            $FindingDetails += "IdentityReference:`t`t$($Object.IdentityReference)" | Out-String
            $FindingDetails += "ActiveDirectoryRights:`t$($Object.ActiveDirectoryRights)" | Out-String
            $FindingDetails += "ObjectType:`t`t`t$($Object.ObjectType)" | Out-String
        }
    }
    Else {
        $Status = "NotAFinding"
    }
    #---=== End Custom Code ===---#

    if ($FindingDetails.Trim().Length -gt 0) {
        $ResultHash = Get-TextHash -Text $FindingDetails -Algorithm SHA1
    }
    else {
        $ResultHash = ""
    }

    if ($PSBoundParameters.AnswerFile) {
        $GetCorpParams = @{
            AnswerFile   = $PSBoundParameters.AnswerFile
            VulnID       = $VulnID
            RuleID       = $RuleID
            AnswerKey    = $PSBoundParameters.AnswerKey
            Status       = $Status
            Hostname     = $Hostname
            Username     = $Username
            UserSID      = $UserSID
            Instance     = $Instance
            Database     = $Database
            Site         = $Site
            ResultHash   = $ResultHash
            ResultData   = $FindingDetails
            ShowRun      = $ShowRunningConfig
            ESPath       = $ESPath
            LogPath      = $LogPath
            LogComponent = $LogComponent
            OSPlatform   = $OSPlatform
        }

        $AnswerData = (Get-CorporateComment @GetCorpParams)
        if ($Status -eq $AnswerData.ExpectedStatus) {
            $AFKey = $AnswerData.AFKey
            $AFStatus = $AnswerData.AFStatus
            $Comments = $AnswerData.AFComment | Out-String
        }
    }

    $SendCheckParams = @{
        Module           = $ModuleName
        Status           = $Status
        FindingDetails   = $FindingDetails
        AFKey            = $AFkey
        AFStatus         = $AFStatus
        Comments         = $Comments
        SeverityOverride = $SeverityOverride
        Justification    = $Justification
        HeadInstance     = $Instance
        HeadDatabase     = $Database
        HeadSite         = $Site
        HeadHash         = $ResultHash
    }
    if ($AF_UserHeader) {
        $SendCheckParams.Add("HeadUsername", $Username)
        $SendCheckParams.Add("HeadUserSID", $UserSID)
    }

    return Send-CheckResult @SendCheckParams
}

# SIG # Begin signature block
# MIIkCwYJKoZIhvcNAQcCoIIj/DCCI/gCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCC7A6gun6/923We
# ny153AWnTTTatcxF+EUuKJc3v4STfaCCHiQwggUqMIIEEqADAgECAgMTYdUwDQYJ
# KoZIhvcNAQELBQAwWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJu
# bWVudDEMMAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJ
# RCBDQS03MjAeFw0yNTAzMjUwMDAwMDBaFw0yODAzMjMyMzU5NTlaMIGOMQswCQYD
# VQQGEwJVUzEYMBYGA1UEChMPVS5TLiBHb3Zlcm5tZW50MQwwCgYDVQQLEwNEb0Qx
# DDAKBgNVBAsTA1BLSTEMMAoGA1UECxMDVVNOMTswOQYDVQQDEzJDUy5OQVZBTCBT
# VVJGQUNFIFdBUkZBUkUgQ0VOVEVSIENSQU5FIERJVklTSU9OLjAwMTCCASIwDQYJ
# KoZIhvcNAQEBBQADggEPADCCAQoCggEBALl8XR1aeL1ARA9c9RE46+zVmtnbYcsc
# D6WG/eVPobPKhzYePfW3HZS2FxQQ0yHXRPH6AS/+tjCqpGtpr+MA5J+r5X9XkqYb
# 1+nwfMlXHCQZDLAsmRN4bNDLAtADzEOp9YojDTTIE61H58sRSw6f4uJwmicVkYXq
# Z0xrPO2xC1/B0D7hzBVKmxeVEcWF81rB3Qf9rKOwiWz9icMZ1FkYZAynaScN5UIv
# V+PuLgH0m9ilY54JY4PWEnNByxM/2A34IV5xG3Avk5WiGFMGm1lKCx0BwsKn0PfX
# Kd0RIcu/fkOEcCz7Lm7NfsQQqtaTKRuBAE5mLiD9cmmbt2WcnfAQvPcCAwEAAaOC
# AcIwggG+MB8GA1UdIwQYMBaAFIP0XzXrzNpde5lPwlNEGEBave9ZMDcGA1UdHwQw
# MC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRElEQ0FfNzIuY3Js
# MA4GA1UdDwEB/wQEAwIGwDAWBgNVHSAEDzANMAsGCWCGSAFlAgELKjAdBgNVHQ4E
# FgQUmWLtMKC6vsuXOz9nYQtTtn1sApcwZQYIKwYBBQUHAQEEWTBXMDMGCCsGAQUF
# BzAChidodHRwOi8vY3JsLmRpc2EubWlsL3NpZ24vRE9ESURDQV83Mi5jZXIwIAYI
# KwYBBQUHMAGGFGh0dHA6Ly9vY3NwLmRpc2EubWlsMIGSBgNVHREEgYowgYekgYQw
# gYExCzAJBgNVBAYTAlVTMRgwFgYDVQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNV
# BAsTA0RvRDEMMAoGA1UECxMDUEtJMQwwCgYDVQQLEwNVU04xLjAsBgNVBAMTJUlS
# RUxBTkQuREFOSUVMLkNIUklTVE9QSEVSLjEzODcxNTAzMzgwHwYDVR0lBBgwFgYK
# KwYBBAGCNwoDDQYIKwYBBQUHAwMwDQYJKoZIhvcNAQELBQADggEBAI7+Xt5NkiSp
# YYEaISRpmsKDnEpuoKzvHjEKl41gmTMLnj7mVTLQFm0IULnaLu8FHelUkI+RmFFW
# gHwaGTujbe0H9S6ySzKQGGSt7jrZijYGAWCG/BtRUVgOSLlWZsLxiVCU07femEGT
# 2JQTEhx5/6ADAE/ZT6FZieiDYa7CZ14+1yKZ07x+t5k+hKAHEqdI6+gkInxqwunZ
# 8VFUoPyTJDsiifDXj5LG7+vUr6YNWZfVh2QJJeQ3kmheKLXRIqNAX2Ova3gFUzme
# 05Wp9gAT4vM7Zk86cHAqVFtwOnK/IGRKBWyEW1btJGWM4yk98TxGKh5JSPN4EAln
# 3i2bAfl2BLAwggWNMIIEdaADAgECAhAOmxiO+dAt5+/bUOIIQBhaMA0GCSqGSIb3
# DQEBDAUAMGUxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xJDAiBgNVBAMTG0RpZ2lDZXJ0IEFzc3Vy
# ZWQgSUQgUm9vdCBDQTAeFw0yMjA4MDEwMDAwMDBaFw0zMTExMDkyMzU5NTlaMGIx
# CzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3
# dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBH
# NDCCAiIwDQYJKoZIhvcNAQEBBQADggIPADCCAgoCggIBAL/mkHNo3rvkXUo8MCIw
# aTPswqclLskhPfKK2FnC4SmnPVirdprNrnsbhA3EMB/zG6Q4FutWxpdtHauyefLK
# EdLkX9YFPFIPUh/GnhWlfr6fqVcWWVVyr2iTcMKyunWZanMylNEQRBAu34LzB4Tm
# dDttceItDBvuINXJIB1jKS3O7F5OyJP4IWGbNOsFxl7sWxq868nPzaw0QF+xembu
# d8hIqGZXV59UWI4MK7dPpzDZVu7Ke13jrclPXuU15zHL2pNe3I6PgNq2kZhAkHnD
# eMe2scS1ahg4AxCN2NQ3pC4FfYj1gj4QkXCrVYJBMtfbBHMqbpEBfCFM1LyuGwN1
# XXhm2ToxRJozQL8I11pJpMLmqaBn3aQnvKFPObURWBf3JFxGj2T3wWmIdph2PVld
# QnaHiZdpekjw4KISG2aadMreSx7nDmOu5tTvkpI6nj3cAORFJYm2mkQZK37AlLTS
# YW3rM9nF30sEAMx9HJXDj/chsrIRt7t/8tWMcCxBYKqxYxhElRp2Yn72gLD76GSm
# M9GJB+G9t+ZDpBi4pncB4Q+UDCEdslQpJYls5Q5SUUd0viastkF13nqsX40/ybzT
# QRESW+UQUOsxxcpyFiIJ33xMdT9j7CFfxCBRa2+xq4aLT8LWRV+dIPyhHsXAj6Kx
# fgommfXkaS+YHS312amyHeUbAgMBAAGjggE6MIIBNjAPBgNVHRMBAf8EBTADAQH/
# MB0GA1UdDgQWBBTs1+OC0nFdZEzfLmc/57qYrhwPTzAfBgNVHSMEGDAWgBRF66Kv
# 9JLLgjEtUYunpyGd823IDzAOBgNVHQ8BAf8EBAMCAYYweQYIKwYBBQUHAQEEbTBr
# MCQGCCsGAQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wQwYIKwYBBQUH
# MAKGN2h0dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydEFzc3VyZWRJ
# RFJvb3RDQS5jcnQwRQYDVR0fBD4wPDA6oDigNoY0aHR0cDovL2NybDMuZGlnaWNl
# cnQuY29tL0RpZ2lDZXJ0QXNzdXJlZElEUm9vdENBLmNybDARBgNVHSAECjAIMAYG
# BFUdIAAwDQYJKoZIhvcNAQEMBQADggEBAHCgv0NcVec4X6CjdBs9thbX979XB72a
# rKGHLOyFXqkauyL4hxppVCLtpIh3bb0aFPQTSnovLbc47/T/gLn4offyct4kvFID
# yE7QKt76LVbP+fT3rDB6mouyXtTP0UNEm0Mh65ZyoUi0mcudT6cGAxN3J0TU53/o
# Wajwvy8LpunyNDzs9wPHh6jSTEAZNUZqaVSwuKFWjuyk1T3osdz9HNj0d1pcVIxv
# 76FQPfx2CWiEn2/K2yCNNWAcAgPLILCsWKAOQGPFmCLBsln1VWvPJ6tsds5vIy30
# fnFqI2si/xK4VC0nftg62fC2h5b9W9FcrBjDTZ9ztwGpn1eqXijiuZQwggW4MIID
# oKADAgECAgFIMA0GCSqGSIb3DQEBDAUAMFsxCzAJBgNVBAYTAlVTMRgwFgYDVQQK
# Ew9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJMRYw
# FAYDVQQDEw1Eb0QgUm9vdCBDQSA2MB4XDTIzMDUxNjE2MDIyNloXDTI5MDUxNTE2
# MDIyNlowWjELMAkGA1UEBhMCVVMxGDAWBgNVBAoTD1UuUy4gR292ZXJubWVudDEM
# MAoGA1UECxMDRG9EMQwwCgYDVQQLEwNQS0kxFTATBgNVBAMTDERPRCBJRCBDQS03
# MjCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALi+DvkbsJrZ8W6Dbflh
# Bv6ONtCSv5QQ+HAE/TlN3/9qITfxmlSWc9S702/NjzgTxJv36Jj5xD0+shC9k+5X
# IQNEZHeCU0C6STdJJwoJt2ulrK5bY919JGa3B+/ctujJ6ZAFMROBwo0b18uzeykH
# +bRhuvNGrpYMJljoMRsqcdWbls+I78qz3YZQQuq5f3LziE03wD5eFRsmXt9PrCaR
# FiftqjezlmoiMOdGbr/DFaLDHkrf/fvtQmreIPKQuQFwmw190LvhdUa4yjshnTV9
# nv1Wo22Yc8US2N3vEOwr5oQPLt/bQyhPHvPt6WNJMqjr7grwSrScJNb2Yr7Fz3I/
# 1fECAwEAAaOCAYYwggGCMB8GA1UdIwQYMBaAFBNPPLvbXUUppZRwttqsnkziL8EL
# MB0GA1UdDgQWBBSD9F8168zaXXuZT8JTRBhAWr3vWTAOBgNVHQ8BAf8EBAMCAYYw
# ZwYDVR0gBGAwXjALBglghkgBZQIBCyQwCwYJYIZIAWUCAQsnMAsGCWCGSAFlAgEL
# KjALBglghkgBZQIBCzswDAYKYIZIAWUDAgEDDTAMBgpghkgBZQMCAQMRMAwGCmCG
# SAFlAwIBAycwEgYDVR0TAQH/BAgwBgEB/wIBADAMBgNVHSQEBTADgAEAMDcGA1Ud
# HwQwMC4wLKAqoCiGJmh0dHA6Ly9jcmwuZGlzYS5taWwvY3JsL0RPRFJPT1RDQTYu
# Y3JsMGwGCCsGAQUFBwEBBGAwXjA6BggrBgEFBQcwAoYuaHR0cDovL2NybC5kaXNh
# Lm1pbC9pc3N1ZWR0by9ET0RST09UQ0E2X0lULnA3YzAgBggrBgEFBQcwAYYUaHR0
# cDovL29jc3AuZGlzYS5taWwwDQYJKoZIhvcNAQEMBQADggIBALAs2CLSvmi9+W/r
# cF0rh09yoqQphPSu6lKv5uyc/3pz3mFL+lFUeIdAVihDbP4XKB+wr+Yz34LeeL82
# 79u3MBAEk4xrJOH29uiRBJFTtMdt8GvOecd2pZSGFbDMTt10Bh9N+IvGYclwMkvt
# 26Q+VlZysQr3fQQ8QdO6z4e9jTFR92QmoW4eLyx8CmgZT2CESRl60Ey0A6Gf87Hh
# ntetRp9k0VkFOk7hWfCSUFBhTrmuJBgNB9HP7e5DuPwKUZLICziVxVrZydoyUmyX
# Aki9q6VrUAsm/1/i/YeUInqtXJZ2vs3foMsNa/tVSQ1BG1Wn/1ZfVzWLd+sAA/nk
# CnbsMc61UG8Yec0jC4WMCsmsQKLEfPrt9/U+tEuX9mqeD3dtpR+vq18av8FNd1mY
# zRgFdNc2+P09daj70PslCCb64XAJh1RY4zHPsOA9o+OXdHAX0kpTackvueXyuLb6
# BM0FCaTpq83Y2oH55kM/pPN3brNHUcIkBzqTj48X3WgQbrrwvGTWh4PSGoitnvsB
# nxsBfAFbqugOUEnnIk0an2Vdl3zGXBooAiODnd/n87Ht7psLp7koapfXTGJBClZU
# mSFpdwtI15hvdw9KThK41bC0cLu8lZ4TEFAxSJyuGjxkhBKXeq7LrRSjO8T+bHte
# u6ud36J9k9xg5brIqTW2ripCBEEtMIIGtDCCBJygAwIBAgIQDcesVwX/IZkuQEMi
# DDpJhjANBgkqhkiG9w0BAQsFADBiMQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGln
# aUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNlcnQuY29tMSEwHwYDVQQDExhE
# aWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwHhcNMjUwNTA3MDAwMDAwWhcNMzgwMTE0
# MjM1OTU5WjBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4x
# QTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQw
# OTYgU0hBMjU2IDIwMjUgQ0ExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIICCgKC
# AgEAtHgx0wqYQXK+PEbAHKx126NGaHS0URedTa2NDZS1mZaDLFTtQ2oRjzUXMmxC
# qvkbsDpz4aH+qbxeLho8I6jY3xL1IusLopuW2qftJYJaDNs1+JH7Z+QdSKWM06qc
# hUP+AbdJgMQB3h2DZ0Mal5kYp77jYMVQXSZH++0trj6Ao+xh/AS7sQRuQL37QXbD
# hAktVJMQbzIBHYJBYgzWIjk8eDrYhXDEpKk7RdoX0M980EpLtlrNyHw0Xm+nt5pn
# YJU3Gmq6bNMI1I7Gb5IBZK4ivbVCiZv7PNBYqHEpNVWC2ZQ8BbfnFRQVESYOszFI
# 2Wv82wnJRfN20VRS3hpLgIR4hjzL0hpoYGk81coWJ+KdPvMvaB0WkE/2qHxJ0ucS
# 638ZxqU14lDnki7CcoKCz6eum5A19WZQHkqUJfdkDjHkccpL6uoG8pbF0LJAQQZx
# st7VvwDDjAmSFTUms+wV/FbWBqi7fTJnjq3hj0XbQcd8hjj/q8d6ylgxCZSKi17y
# Vp2NL+cnT6Toy+rN+nM8M7LnLqCrO2JP3oW//1sfuZDKiDEb1AQ8es9Xr/u6bDTn
# YCTKIsDq1BtmXUqEG1NqzJKS4kOmxkYp2WyODi7vQTCBZtVFJfVZ3j7OgWmnhFr4
# yUozZtqgPrHRVHhGNKlYzyjlroPxul+bgIspzOwbtmsgY1MCAwEAAaOCAV0wggFZ
# MBIGA1UdEwEB/wQIMAYBAf8CAQAwHQYDVR0OBBYEFO9vU0rp5AZ8esrikFb2L9RJ
# 7MtOMB8GA1UdIwQYMBaAFOzX44LScV1kTN8uZz/nupiuHA9PMA4GA1UdDwEB/wQE
# AwIBhjATBgNVHSUEDDAKBggrBgEFBQcDCDB3BggrBgEFBQcBAQRrMGkwJAYIKwYB
# BQUHMAGGGGh0dHA6Ly9vY3NwLmRpZ2ljZXJ0LmNvbTBBBggrBgEFBQcwAoY1aHR0
# cDovL2NhY2VydHMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZFJvb3RHNC5j
# cnQwQwYDVR0fBDwwOjA4oDagNIYyaHR0cDovL2NybDMuZGlnaWNlcnQuY29tL0Rp
# Z2lDZXJ0VHJ1c3RlZFJvb3RHNC5jcmwwIAYDVR0gBBkwFzAIBgZngQwBBAIwCwYJ
# YIZIAYb9bAcBMA0GCSqGSIb3DQEBCwUAA4ICAQAXzvsWgBz+Bz0RdnEwvb4LyLU0
# pn/N0IfFiBowf0/Dm1wGc/Do7oVMY2mhXZXjDNJQa8j00DNqhCT3t+s8G0iP5kvN
# 2n7Jd2E4/iEIUBO41P5F448rSYJ59Ib61eoalhnd6ywFLerycvZTAz40y8S4F3/a
# +Z1jEMK/DMm/axFSgoR8n6c3nuZB9BfBwAQYK9FHaoq2e26MHvVY9gCDA/JYsq7p
# GdogP8HRtrYfctSLANEBfHU16r3J05qX3kId+ZOczgj5kjatVB+NdADVZKON/gnZ
# ruMvNYY2o1f4MXRJDMdTSlOLh0HCn2cQLwQCqjFbqrXuvTPSegOOzr4EWj7PtspI
# HBldNE2K9i697cvaiIo2p61Ed2p8xMJb82Yosn0z4y25xUbI7GIN/TpVfHIqQ6Ku
# /qjTY6hc3hsXMrS+U0yy+GWqAXam4ToWd2UQ1KYT70kZjE4YtL8Pbzg0c1ugMZyZ
# Zd/BdHLiRu7hAWE6bTEm4XYRkA6Tl4KSFLFk43esaUeqGkH/wyW4N7OigizwJWeu
# kcyIPbAvjSabnf7+Pu0VrFgoiovRDiyx3zEdmcif/sYQsfch28bZeUz2rtY/9TCA
# 6TD8dC3JE3rYkrhLULy7Dc90G6e8BlqmyIjlgp2+VqsS9/wQD7yFylIz0scmbKvF
# oW2jNrbM1pD2T7m3XDCCBu0wggTVoAMCAQICEAqA7xhLjfEFgtHEdqeVdGgwDQYJ
# KoZIhvcNAQELBQAwaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJ
# bmMuMUEwPwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBS
# U0E0MDk2IFNIQTI1NiAyMDI1IENBMTAeFw0yNTA2MDQwMDAwMDBaFw0zNjA5MDMy
# MzU5NTlaMGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7
# MDkGA1UEAxMyRGlnaUNlcnQgU0hBMjU2IFJTQTQwOTYgVGltZXN0YW1wIFJlc3Bv
# bmRlciAyMDI1IDEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDQRqwt
# Esae0OquYFazK1e6b1H/hnAKAd/KN8wZQjBjMqiZ3xTWcfsLwOvRxUwXcGx8AUjn
# i6bz52fGTfr6PHRNv6T7zsf1Y/E3IU8kgNkeECqVQ+3bzWYesFtkepErvUSbf+EI
# YLkrLKd6qJnuzK8Vcn0DvbDMemQFoxQ2Dsw4vEjoT1FpS54dNApZfKY61HAldytx
# NM89PZXUP/5wWWURK+IfxiOg8W9lKMqzdIo7VA1R0V3Zp3DjjANwqAf4lEkTlCDQ
# 0/fKJLKLkzGBTpx6EYevvOi7XOc4zyh1uSqgr6UnbksIcFJqLbkIXIPbcNmA98Os
# kkkrvt6lPAw/p4oDSRZreiwB7x9ykrjS6GS3NR39iTTFS+ENTqW8m6THuOmHHjQN
# C3zbJ6nJ6SXiLSvw4Smz8U07hqF+8CTXaETkVWz0dVVZw7knh1WZXOLHgDvundrA
# tuvz0D3T+dYaNcwafsVCGZKUhQPL1naFKBy1p6llN3QgshRta6Eq4B40h5avMcpi
# 54wm0i2ePZD5pPIssoszQyF4//3DoK2O65Uck5Wggn8O2klETsJ7u8xEehGifgJY
# i+6I03UuT1j7FnrqVrOzaQoVJOeeStPeldYRNMmSF3voIgMFtNGh86w3ISHNm0Ia
# adCKCkUe2LnwJKa8TIlwCUNVwppwn4D3/Pt5pwIDAQABo4IBlTCCAZEwDAYDVR0T
# AQH/BAIwADAdBgNVHQ4EFgQU5Dv88jHt/f3X85FxYxlQQ89hjOgwHwYDVR0jBBgw
# FoAU729TSunkBnx6yuKQVvYv1Ensy04wDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB
# /wQMMAoGCCsGAQUFBwMIMIGVBggrBgEFBQcBAQSBiDCBhTAkBggrBgEFBQcwAYYY
# aHR0cDovL29jc3AuZGlnaWNlcnQuY29tMF0GCCsGAQUFBzAChlFodHRwOi8vY2Fj
# ZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdS
# U0E0MDk2U0hBMjU2MjAyNUNBMS5jcnQwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDov
# L2NybDMuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5n
# UlNBNDA5NlNIQTI1NjIwMjVDQTEuY3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsG
# CWCGSAGG/WwHATANBgkqhkiG9w0BAQsFAAOCAgEAZSqt8RwnBLmuYEHs0QhEnmNA
# ciH45PYiT9s1i6UKtW+FERp8FgXRGQ/YAavXzWjZhY+hIfP2JkQ38U+wtJPBVBaj
# YfrbIYG+Dui4I4PCvHpQuPqFgqp1PzC/ZRX4pvP/ciZmUnthfAEP1HShTrY+2DE5
# qjzvZs7JIIgt0GCFD9ktx0LxxtRQ7vllKluHWiKk6FxRPyUPxAAYH2Vy1lNM4kze
# kd8oEARzFAWgeW3az2xejEWLNN4eKGxDJ8WDl/FQUSntbjZ80FU3i54tpx5F/0Kr
# 15zW/mJAxZMVBrTE2oi0fcI8VMbtoRAmaaslNXdCG1+lqvP4FbrQ6IwSBXkZagHL
# hFU9HCrG/syTRLLhAezu/3Lr00GrJzPQFnCEH1Y58678IgmfORBPC1JKkYaEt2Od
# Dh4GmO0/5cHelAK2/gTlQJINqDr6JfwyYHXSd+V08X1JUPvB4ILfJdmL+66Gp3CS
# BXG6IwXMZUXBhtCyIaehr0XkBoDIGMUG1dUtwq1qmcwbdUfcSYCn+OwncVUXf53V
# JUNOaMWMts0VlRYxe5nK+At+DI96HAlXHAL5SlfYxJ7La54i71McVWRP66bW+yER
# NpbJCjyCYG2j+bdpxo/1Cy4uPcU3AWVPGrbn5PhDBf3Froguzzhk++ami+r3Qrx5
# bIbY3TVzgiFI7Gq3zWcxggU9MIIFOQIBATBhMFoxCzAJBgNVBAYTAlVTMRgwFgYD
# VQQKEw9VLlMuIEdvdmVybm1lbnQxDDAKBgNVBAsTA0RvRDEMMAoGA1UECxMDUEtJ
# MRUwEwYDVQQDEwxET0QgSUQgQ0EtNzICAxNh1TANBglghkgBZQMEAgEFAKCBhDAY
# BgorBgEEAYI3AgEMMQowCKACgAChAoAAMBkGCSqGSIb3DQEJAzEMBgorBgEEAYI3
# AgEEMBwGCisGAQQBgjcCAQsxDjAMBgorBgEEAYI3AgEVMC8GCSqGSIb3DQEJBDEi
# BCC/2Smc8iF4n76zuxwaynlBj6jLcpbwRiQ1SoMLdoJ6dDANBgkqhkiG9w0BAQEF
# AASCAQB3kRmAOUeEM2/bKhS+fW14MBlLZhyEgYvhPORpCcVfqAoS47RO1zs4sZxL
# YSq3qXZH7pkSwcdEX/93MUU/knHviy3TQicLyV7Domp6EHy5XrgZU8YvU9RZLL5G
# 1iJNQG5B6sgSsXCGOQ5yLzEpae4JtOLSvNa7ykvOYnhxIAOF4ZN8eKItyetfkkqK
# JUC7rStkDe83fh1pUEbAp4mmoXFWgJOnCNZmMyR8EbBFIRgLxz5DCMcO1Ck6dKKq
# Y3cvZmynOKlBiVOWahsKMgkuxoI6n5T4GnnZJ8uF25slklcDUdP/9Ai9QTXhQ1Yv
# uMuvv3c9i1SLF5Y9qI66/f2N1UBZoYIDJjCCAyIGCSqGSIb3DQEJBjGCAxMwggMP
# AgEBMH0waTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEw
# PwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2
# IFNIQTI1NiAyMDI1IENBMQIQCoDvGEuN8QWC0cR2p5V0aDANBglghkgBZQMEAgEF
# AKBpMBgGCSqGSIb3DQEJAzELBgkqhkiG9w0BBwEwHAYJKoZIhvcNAQkFMQ8XDTI1
# MTIxMTE4NTExMlowLwYJKoZIhvcNAQkEMSIEIGNfA50Qs8fctFcYfwyO5HmcXDTh
# /dLmtmuIOpGNtTvNMA0GCSqGSIb3DQEBAQUABIICAMSzXHXkmMPb/KU7W67b7Hv9
# wgqrMfl4hIE3ZNLwAtYonG8Gu5W8OTMPCmBucS2reJeId7vRwIeklg/Ie2eWI4W5
# 3WRJwBYJ5rI9PF/nEcZq6OE61FP3+Y6p0gpvYLBgonQuQudMJbwBEdly/xnRRabd
# aSg4XLlBPyG9CzGgLULJJRjzEARNEsJkgoN+bFCxYFHpXg+8ibu7Acum+D/1U1jn
# AGxXfU5txbXAKEBCsesK0dpXrxSH7+eLWjQRGDNb2FQJ6l2KN13Vm8TKwK9icber
# 3jIemvZzUp3WcII7TGD68Nucc33LzPqzyTlqZLWH0UXnAtOyBEqeR0IqCbFfk6Ml
# /KuOWKa/Eap94upU0D/UyR+bAnryEhOKkiT+748hjwRdrLN6W7sCAE7wCzaixazA
# WNDwJix+9zHsHcxpWm5YfUHRW+c6SFchW5XnKn8mRf9HjsmRs6b+zJX2Z/WFV1OG
# 5uoDQZovz9hb6m2sxy7sYineCeh1f2b4JYdYpTqKOr30p3RRDHBj37IED8mDWF9T
# sMMWtDHlq6TG940WmQkpTFbXAEv7DTOxgsJc8tvN0JHipG0in2EhxDfUuv7ToITh
# c7ww8pYfOALRsOAcHYpAS4LQdm5jbafBK5n2R+oYWpI1HwQ6dbz2onCspXT3yDjE
# 3aiDxPytG8SESjwSBnx9
# SIG # End signature block
