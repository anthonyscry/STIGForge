# PowerSTIG File Hashes : Module Version 4.24.0

Hashes for **PowerSTIG** files are listed in the following table:

| File | SHA256 Hash | Size (bytes) |
| :---- | ---- | ---: |
