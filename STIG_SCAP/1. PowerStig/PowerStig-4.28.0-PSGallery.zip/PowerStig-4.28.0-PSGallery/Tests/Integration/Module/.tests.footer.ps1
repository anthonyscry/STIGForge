# Integration test footer
Remove-Module $script:moduleName
